export class Brands {
  name: string;
  email: string;
  companyURl: string;
  username: string;
  address: string;
  currency: string;
  businessKey: string;
  description: string;
  image: string;
  brandID: number;
  statusID: number;
}