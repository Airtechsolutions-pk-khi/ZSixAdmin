export class Offers {
  customerID: number;
  fullName: string;
  email: string;
  mobile: string;
  password: string;
  image: string;
  locationID: number;
  brandID: number;
  statusID: number;
}