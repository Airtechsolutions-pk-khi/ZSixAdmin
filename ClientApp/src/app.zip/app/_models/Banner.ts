export class Banner {
  bannerID: number;
  name: string;
  description: string;
  image: string;
  brandID: number;
  statusID: number;
}