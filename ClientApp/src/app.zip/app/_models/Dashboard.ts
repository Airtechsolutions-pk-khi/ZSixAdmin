export class DashboardSummary {
  totalOrders: number;
  totalTax: number;
  netSales: number;
  sales: number;
 
}